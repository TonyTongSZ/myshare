﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.PowerPoint;
using Microsoft.Office.Core;


namespace PdfCreator
{
    using System.Runtime.InteropServices;
    using System.Configuration;
    using System.Security.Cryptography;
    using log4net;

    public partial class MainForm : Form
    {
        private const String Caption_Start = "转换";
        private const String Caption_Pause = "暂停";
        private const String Caption_Continue = "继续";
        private Microsoft.Office.Interop.Word.Application _appWord;
        private Microsoft.Office.Interop.Excel.Application _appExcel;
        private Microsoft.Office.Interop.PowerPoint.Application _appPpt;

        private delegate void AddLog(String msg,Color? color);
        private delegate void SetProgress(int value);
        private delegate void DoneProc(bool cancel);   
        private delegate void ConvertFile(FileInfo f);
        private bool isPaused = false;
        private bool isTerminated = false;
        private int cnt = 0;
        private int processCnt = 0;
        private int doneCnt = 0;       
        private int successCnt = 0;
        private int failurCnt = 0;
        private DateTime startTime = DateTime.Now;
        private bool onWorking = false;

        private byte[] EncryptMagicCode = System.Text.Encoding.UTF8.GetBytes("TONCENT");
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public MainForm()
        {
            InitializeComponent();
            reset();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (btnProcess.Text == Caption_Start)
            {
                processStart();
            }
            else if (btnProcess.Text == Caption_Pause)
            {
                btnProcess.Text = Caption_Continue;
                isPaused = true;
            } else if(btnProcess.Text == Caption_Continue)
            {
                btnProcess.Text = Caption_Pause;
                isPaused = false;
            }
        }

        private void processStart()
        {
            if (String.IsNullOrEmpty(txtFileName.Text))
            {
                MessageBox.Show("请选择一个包含所有待转换文件的源目录", "错误");
                return;
            }
            btnBrows.Enabled = false;
            btnDestBrowse.Enabled = false;
            isPaused = false;
            isTerminated = false;
            List<FileInfo> files = GetFiles(new DirectoryInfo(txtFileName.Text));
            progress.Maximum = files.Count;
            progress.Value = 0;
            this.MinimumSize = new Size(this.MinimumSize.Width, 368);
            this.Height = 368;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            pnlInfo.Visible = true;
            Thread thread = new Thread(
                () => {
                    ConvertFiels(files);
                });
            thread.Name = "ProcessFiles";
            btnProcess.Text = Caption_Pause;
            btnStop.Visible = true;
            cnt = files.Count;            
            txtLog.Text = "";
            startTime = DateTime.Now;
            onWorking = true;
            thread.Start();
        }

        private List<FileInfo> GetFiles(DirectoryInfo folder)
        {
            List<FileInfo> fileList = new List<FileInfo>();            
            if (!folder.Exists) return fileList;            
            FileInfo[] files = folder.GetFiles("*.*");
            fileList.AddRange(files);
            DirectoryInfo[] subFolders = folder.GetDirectories();
            foreach(DirectoryInfo subFolder in subFolders)
            {
                fileList.AddRange(GetFiles(subFolder));
            }
            return fileList;
        }

        private void ConvertFiels(List<FileInfo> files)
        {
            AddLog addLog = this.addLog;
            SetProgress setProgress = new SetProgress((v)=> { progress.Value = v; });
            DoneProc doneProc = new DoneProc(doneProcess);
            int i = 0;
            foreach(FileInfo f in files)
            {                
                if (isTerminated)
                {
                    this.Invoke(doneProc,true);
                    return;
                }
                while (isPaused) { 
                    Thread.Yield();
                    if (isTerminated)
                    {
                        this.Invoke(doneProc, true);
                        return;
                    }
                };
                i++;
                ConvertFile method = getConvertFileMethod(f);
                if (method == null)
                {
                    copyFile(f);
                    this.Invoke(addLog, String.Format("发现不支持的文件 {0}，文件已直接复制到目标目录。\r\n", f.FullName), Color.FromArgb(165, 165, 165));
                    log.WarnFormat("发现不支持的文件 {0}，文件已直接复制到目标目录", f.FullName);
                    this.Invoke(setProgress, i);                    
                    continue;
                }
                processCnt++;
                this.Invoke(addLog, String.Format("正在转换文件{0} {1} ...", i, f.FullName), null); 
                try
                {
                    method(f);
                    successCnt++;
                    this.Invoke(addLog, " 完成\r\n",null);
                    log.InfoFormat("成功转换第{0}个文件 {1}",i,f.FullName);   
                } catch (Exception e)
                {
                    failurCnt++;
                    this.Invoke(addLog, String.Format(" 转换失败，失败原因：{0}\r\n", e.Message), Color.Red);
                    log.ErrorFormat("第{0}个文件 {1} 转换失败，失败原因:{2}", i, f.FullName, e.Message);
                    //log.Error(e.Message, e);
                }
                doneCnt++;
                this.Invoke(setProgress,i);                
            }
            this.Invoke(doneProc,false);
        }

        private ConvertFile getConvertFileMethod(FileInfo f)
        {           
            if (".doc".Equals(f.Extension, StringComparison.OrdinalIgnoreCase) || ".docx".Equals(f.Extension, StringComparison.OrdinalIgnoreCase))
            {
                return wordToPdf;
            }
            else if (".xls".Equals(f.Extension, StringComparison.OrdinalIgnoreCase) || ".xlsx".Equals(f.Extension, StringComparison.OrdinalIgnoreCase))
            {
                return excelToPdf;
            }
            else if (".ppt".Equals(f.Extension, StringComparison.OrdinalIgnoreCase) || ".pptx".Equals(f.Extension, StringComparison.OrdinalIgnoreCase))
            {
                return pptToPdf;
            }
            else
            {
                return null;
            }            
        }

        private void doneProcess(bool cancel)
        {
            String msg = cancel ? "转换过程已被人为取消！" : "转换完成！";            
            TimeSpan timespan = DateTime.Now - startTime;
            String sTime = (timespan.Days > 0 ? timespan.Days + "天" : "") + (timespan.Hours > 0 ? timespan.Hours + "小时" : "") + (timespan.Minutes > 0 ? timespan.Minutes + "分" : "") + (timespan.Seconds > 0 ? timespan.Seconds + "秒" : "");
            if (sTime == "") sTime = "不到1秒";
            Color? c = null;
            if (cancel) c = Color.Red;
            msg = String.Format("{0} 共发现了文件{1}个，转换了{2}个文件，其中转换成功{3}个，转换失败{4}个，直接复制文件{5}个，共耗时{6}\r\n\r\n", msg, cnt, doneCnt, successCnt, failurCnt, progress.Value - processCnt, sTime);
            addLog(msg, c);
            log.InfoFormat(msg);            
            MessageBox.Show(msg, cancel ? "取消" : "成功");
            reset();
        }

        private void reset()
        {
            btnProcess.Text = Caption_Start;
            btnStop.Visible = false;
            cnt = 0;
            processCnt = 0;
            doneCnt = 0;
            successCnt = 0;
            failurCnt = 0;
            onWorking = false;
            btnBrows.Enabled = true;
            btnDestBrowse.Enabled = true;
        }

        private void addLog(String msg, Color? c = null)
        {
            if (c == null) c = Color.FromArgb(43, 145, 175);
            int lineStart = txtLog.Text.LastIndexOf('\n') + 1;           
            txtLog.AppendText(msg);
            txtLog.Select(lineStart, txtLog.Text.Length);
            //txtLog.SelectionStart = lastNewLine;
            txtLog.SelectionColor = c.Value;

            txtLog.SelectionStart = txtLog.Text.Length;          
            txtLog.ScrollToCaret();
        }

        private void copyFile(FileInfo f){
            String destFileName = getDestFileName(f);
            if (new FileInfo(destFileName).Exists) return;
            f.CopyTo(destFileName, true);
        }

        private void wordToPdf(FileInfo f)
        {
            String destFileName = getDestPdfFileName(f);
            if (new FileInfo(destFileName).Exists) return;
            object missing = System.Reflection.Missing.Value;
            Document wordDocument = appWord.Documents.Open(f.FullName);
            wordDocument.ExportAsFixedFormat(destFileName, WdExportFormat.wdExportFormatPDF);
            wordDocument.Close(Type.Missing,Type.Missing,Type.Missing);
        }

        private void excelToPdf(FileInfo f)
        {
            String destFileName = getDestPdfFileName(f);
            if (new FileInfo(destFileName).Exists) return;           
            Workbook book = appExcel.Workbooks.Open(f.FullName);           
            book.ExportAsFixedFormat(XlFixedFormatType.xlTypePDF, destFileName);
            book.Close();
        }

        private void pptToPdf(FileInfo f)
        {
            String destFileName = getDestPdfFileName(f);
            if (new FileInfo(destFileName).Exists) return;           
            Presentation ppt = appPpt.Presentations.Open(f.FullName, MsoTriState.msoTrue, MsoTriState.msoTrue, MsoTriState.msoFalse);
            ppt.ExportAsFixedFormat(destFileName, PpFixedFormatType.ppFixedFormatTypePDF);
            ppt.Close();

        }

        private void makeFolders(String s)
        {
            Directory.CreateDirectory(new FileInfo(s).Directory.FullName);            
        }

        private string getDestFileName(FileInfo f,bool makeFolderIfNotExist = true)
        {
            String s = f.FullName.Replace(txtFileName.Text, txtDestFolder.Text);
            if(makeFolderIfNotExist) makeFolders(s);
            return s;
        }

        private string getDestPdfFileName(FileInfo f, bool makeFolderIfNotExist = true)
        {
            String s = f.FullName.Replace(txtFileName.Text, txtDestFolder.Text);
            s = s.Substring(0, s.Length - f.Extension.Length) + ".pdf";
            if (makeFolderIfNotExist) makeFolders(s);
            return s;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrows_Click(object sender, EventArgs e)
        {
            if (onWorking)
            {
                if (MessageBox.Show("转换工作正在进行中，您要中断当前操作吗？", "确认", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    btnStop_Click(null,null);
                }
                else
                {
                    return;
                }
            }

            if (folderSelect.ShowDialog() == DialogResult.OK)
            {
                String oldPath = txtFileName.Text;
                txtFileName.Text = folderSelect.SelectedPath;
                if (String.IsNullOrWhiteSpace(txtDestFolder.Text) || txtDestFolder.Text.Equals(oldPath + "_pdf"))
                {
                    txtDestFolder.Text = txtFileName.Text + "_pdf";
                }
                
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            isTerminated = true;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Height = 168;
            this.Width = 445;
        }

        private void btnDestBrowse_Click(object sender, EventArgs e)
        {
            if (folderSelect.ShowDialog() == DialogResult.OK)
            {                
                txtDestFolder.Text = folderSelect.SelectedPath;               
            }
        }

        private Microsoft.Office.Interop.Word.Application appWord{
            get{
                if(_appWord==null){
                    _appWord = new Microsoft.Office.Interop.Word.Application();
                }
                return _appWord;
            }
        }

        private Microsoft.Office.Interop.Excel.Application appExcel
        {
            get
            {
                if (_appExcel == null)
                {
                    _appExcel = new Microsoft.Office.Interop.Excel.Application();
                }
                return _appExcel;
            }
        }



        private Microsoft.Office.Interop.PowerPoint.Application appPpt
        {
            get
            {
                if (_appPpt == null)
                {
                    _appPpt = new Microsoft.Office.Interop.PowerPoint.Application();
                }
                return _appPpt;
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_appWord!=null)
            {
                _appWord.Quit();
            }
            if (_appExcel != null)
            {
                _appExcel.Quit();
            }
            if (_appPpt != null)
            {
                _appPpt.Quit();
            }
        }

        
    }
}
