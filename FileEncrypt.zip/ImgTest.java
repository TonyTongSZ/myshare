package test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.apache.commons.io.FileUtils;

public class ImgTest {
	
	public static void main(String[] args) throws Exception {
		encriptOrDecriptFile("C:/Users/tongt/Desktop/pdftest/formgen/formgen.zip");
	}
	
	public static void encriptOrDecriptFile(String fileName) throws Exception {
		File f = new File(fileName);
		if(!f.exists() || !f.isFile()) throw new RuntimeException("bad file");
		File f1 = new File(fileName+".tmp"); 
		InputStream in = new BufferedInputStream(new FileInputStream(f)) ;
		OutputStream out = new BufferedOutputStream(new FileOutputStream(f1));
		int n = 0;
		int c;
		byte[] salt = getMD5Key("88888888");		
		while((c = in.read()) != -1) {			
			if(n<8) {
				out.write(c);
			} else {
				int c1 = salt[n % salt.length];
				out.write(c^c1);
			}
			n++;
		}
		in.close();
		out.flush();
		out.close();
		FileUtils.forceDelete(f);
		FileUtils.moveFile(f1, f);
	}	

	
	public static byte[] getMD5Key(String psd) throws Exception {
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] hashInBytes = md.digest(psd.getBytes(StandardCharsets.UTF_8));
		return hashInBytes;
	}

}
