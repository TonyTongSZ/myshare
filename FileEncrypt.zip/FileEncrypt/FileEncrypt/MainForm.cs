﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;



namespace PdfEncrypt
{
    using System.Runtime.InteropServices;
    using iTextSharp.text.pdf;
    using iTextSharp.text;
    using System.Configuration;
    using System.Security.Cryptography;

    public partial class MainForm : Form
    {
        private delegate void AddLog(String msg,Color? color);
        private delegate void SetProgress(int value);
        private delegate void DoneProc(bool cancel);   
        private delegate void EncriptFile(FileInfo f);
        private bool isPursed = false;
        private bool isTerminated = false;
        private int cnt = 0;
        private int processCnt = 0;
        private int doneCnt = 0;       
        private int successCnt = 0;
        private int failurCnt = 0;
        private DateTime startTime = DateTime.Now;
        private bool onWorking = false;
        private const String DEFAULT_PSD = "66666666";
        private String[] imageFileExts = null;
        private byte[] md5HashForPsd = null;
        private String password = null;

        public MainForm()
        {
            PdfReader.unethicalreading = true;
            String extForImage = ConfigurationManager.AppSettings["extForImage"];
            imageFileExts = extForImage.Split(new char[] {','});
            password = ConfigurationManager.AppSettings["password"];
            if (String.IsNullOrWhiteSpace(password)) password = DEFAULT_PSD;
            MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(password);
            md5HashForPsd = md5.ComputeHash(inputBytes);
            InitializeComponent();            
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (btnProcess.Text == "加密")
            {
                processStart();
            } else if(btnProcess.Text == "暂停")
            {
                btnProcess.Text = "继续";
                isPursed = true;
            } else if(btnProcess.Text == "继续")
            {
                btnProcess.Text = "暂停";
                isPursed = false;
            }
        }

        private void processStart()
        {
            if (String.IsNullOrEmpty(txtFileName.Text))
            {
                MessageBox.Show("请选择一个文件夹", "错误");
                return;
            }
            isPursed = false;
            isTerminated = false;
            List<FileInfo> files = GetFiles(new DirectoryInfo(txtFileName.Text));
            progress.Maximum = files.Count;
            progress.Value = 0;
            this.MinimumSize = new Size(this.MinimumSize.Width, 368);
            this.Height = 368;
            this.FormBorderStyle = FormBorderStyle.Sizable;
            pnlInfo.Visible = true;
            Thread thread = new Thread(
                () => {
                    EncryptFiels(files);
                });
            thread.Name = "ProcessFiles";
            btnProcess.Text = "暂停";
            btnStop.Visible = true;
            cnt = files.Count;            
            txtLog.Text = "";
            startTime = DateTime.Now;
            onWorking = true;
            thread.Start();
        }

        private void processPurse()
        {
            btnProcess.Text = "继续";
            isPursed = true;
        }

        private void processResume()
        {
            btnProcess.Text = "暂停";
            isPursed = false;
        }

        private List<FileInfo> GetFiles(DirectoryInfo folder)
        {
            List<FileInfo> fileList = new List<FileInfo>();            
            if (!folder.Exists) return fileList;            
            FileInfo[] files = folder.GetFiles("*.*");
            fileList.AddRange(files);
            DirectoryInfo[] subFolders = folder.GetDirectories();
            foreach(DirectoryInfo subFolder in subFolders)
            {
                fileList.AddRange(GetFiles(subFolder));
            }
            return fileList;
        }

        private void EncryptFiels(List<FileInfo> files)
        {
            AddLog addLog = this.addLog;
            SetProgress setProgress = new SetProgress((v)=> { progress.Value = v; });
            DoneProc doneProc = new DoneProc(doneProcess);
            int i = 0;
            foreach(FileInfo f in files)
            {                
                if (isTerminated)
                {
                    this.Invoke(doneProc,true);
                    return;
                }
                while (isPursed) { 
                    Thread.Yield();
                    if (isTerminated)
                    {
                        this.Invoke(doneProc, true);
                        return;
                    }
                };
                i++;
                EncriptFile encryptFile = getEncriptFileMethod(f);
                if (encryptFile == null)
                {
                    this.Invoke(addLog, String.Format("发现不支持的文件 {0}，文件已忽略。\r\n", f.FullName), Color.FromArgb(165, 165, 165));
                    this.Invoke(setProgress, i);
                    continue;
                }
                processCnt++;
                this.Invoke(addLog, String.Format("正在处理文件{0} {1} ...",i,f.FullName),null); 
                try
                {
                    encryptFile(f);
                    successCnt++;
                    this.Invoke(addLog, " 完成\r\n",null);                            
                } catch (Exception e)
                {
                    failurCnt++;
                    this.Invoke(addLog, String.Format(" 处理失败，失败原因：{0}\r\n", e.Message), Color.Red);
                }
                doneCnt++;
                this.Invoke(setProgress,i);                
            }
            this.Invoke(doneProc,false);
        }

        private EncriptFile getEncriptFileMethod(FileInfo f)
        {
            if (f.Extension.Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            {
                return EncryptPDFFile;
            }
            else if (isImageFile(f))
            {
                return EncryptImageFile;
            }
            else
            {
                return null;
            }            
        }

        private bool isImageFile(FileInfo f)
        {
            return Array.Exists(imageFileExts,ext => ext.Equals(f.Extension, StringComparison.OrdinalIgnoreCase));
        }

        private void doneProcess(bool cancel)
        {
            String msg = cancel ? "加密过程已被人为取消！" : "加密完成！";            
            TimeSpan timespan = DateTime.Now - startTime;
            String sTime = (timespan.Days > 0 ? timespan.Days + "天" : "") + (timespan.Hours > 0 ? timespan.Hours + "小时" : "") + (timespan.Minutes > 0 ? timespan.Minutes + "分" : "") + (timespan.Seconds > 0 ? timespan.Seconds + "秒" : "");
            if (sTime == "") sTime = "不到1秒";
            Color? c = null;
            if (cancel) c = Color.Red;
            msg = String.Format("{0} 共发现了文件{1}个，处理了{2}个文件，其中处理成功{3}个，处理失败{4}个，跳过文件{5}个，共耗时{6}\r\n", msg, cnt, doneCnt, successCnt, failurCnt, progress.Value - processCnt, sTime);
            addLog(msg, c);
            MessageBox.Show(msg, cancel ? "取消" : "成功");
            reset();
        }

        private void reset()
        {
            btnProcess.Text = "加密";
            btnStop.Visible = false;
            cnt = 0;
            processCnt = 0;
            doneCnt = 0;
            successCnt = 0;
            failurCnt = 0;
            onWorking = false;
        }

        private void addLog(String msg, Color? c = null)
        {
            if (c == null) c = Color.FromArgb(43, 145, 175);
            int lineStart = txtLog.Text.LastIndexOf('\n') + 1;           
            txtLog.AppendText(msg);
            txtLog.Select(lineStart, txtLog.Text.Length);
            //txtLog.SelectionStart = lastNewLine;
            txtLog.SelectionColor = c.Value;

            txtLog.SelectionStart = txtLog.Text.Length;          
            txtLog.ScrollToCaret();
        }

        private void EncryptPDFFile(FileInfo f)
        {
            String f1 = f.FullName + ".tmp";
            try
            {
                using (PdfReader r = new PdfReader(f.FullName))                
                    using (Document document = new Document(r.GetPageSize(1)))
                    {
                        int n = r.NumberOfPages;
                        FileStream stream = new FileStream(f1, FileMode.Create);
                        PdfCopy copy = new PdfCopy(document, stream);

                        copy.SetEncryption(PdfWriter.STRENGTH128BITS, password, null, PdfWriter.AllowCopy | PdfWriter.AllowPrinting);
                        document.Open();
                        for (int i = 1; i <= n; i++)
                        {
                            PdfImportedPage page = copy.GetImportedPage(r, i);
                            copy.AddPage(page);
                        }
                    } 
                File.Delete(f.FullName);
                File.Move(f1, f.FullName);
            }
            catch (iTextSharp.text.exceptions.BadPasswordException e)
            {
                throw new Exception("该文件已是加密文件，故加密失败。");
            }
            finally
            {
                FileInfo tmpF = new FileInfo(f1);
                if (tmpF.Exists) try { tmpF.Delete(); }
                    catch (Exception) { }
            }
        }

        private void EncryptImageFile(FileInfo f)
        {
            String f1 = f.FullName + ".tmp";
            try
            {
                var buffer = new byte[65536];
                using (Stream fIn = File.OpenRead(f.FullName), fOut = File.OpenWrite(f1))
                {
                    
                    int readCnt = 0;
                    int pos = 0;
                    while (readCnt < fIn.Length)
                    {
                        int cnt = fIn.Read(buffer, 0, buffer.Length);
                        for (int i = 0; i < cnt; i++)
                        {
                            if (pos >= 0)
                            {
                                buffer[i] = (byte)(buffer[i] ^ md5HashForPsd[pos % md5HashForPsd.Length]);
                            }
                            pos++;
                        }
                        fOut.Write(buffer, 0, cnt);
                        readCnt += cnt;
                    }
                    fOut.Flush();
                }
                File.Delete(f.FullName);
                File.Move(f1, f.FullName);
            }
            finally
            {
                FileInfo tmpF = new FileInfo(f1);
                if (tmpF.Exists) try { tmpF.Delete(); }
                    catch (Exception) { }
            }

        }
          

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrows_Click(object sender, EventArgs e)
        {
            if (onWorking)
            {
                if (MessageBox.Show("加密操作正在进行中，您要中断当前操作吗？", "确认", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    btnStop_Click(null,null);
                }
                else
                {
                    return;
                }
            }

            if (folderSelect.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = folderSelect.SelectedPath;
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            isTerminated = true;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Height = 148;
            this.Width = 445;
        }
    }
}
